"""
router.py — Tutti gli endpoint API v1.
"""
import uuid
from datetime import date
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.core.security import (
    verify_password, create_access_token,
    get_current_user, require_roles
)
from app.models.models import User, UserRole, CommessaStatus, TimesheetStatus
from app.schemas.schemas import (
    LoginRequest, TokenResponse, UserOut, UserCreate, UserUpdate,
    ClienteCreate, ClienteUpdate, ClienteOut,
    ProgettoCreate, ProgettoUpdate, ProgettoOut, ProgettoWithCliente,
    CommessaCreate, CommessaUpdate, CommessaOut, CommessaWithProgetto,
    TimesheetCreate, TimesheetOut, TimesheetApprova,
    CostoCreate, CostoOut,
    CoefficienteCreate, CoefficienteOut,
    DashboardKpi, MarginalitaCliente,
)
from app.services.services import (
    get_user_by_email, create_user, list_users, update_user,
    list_clienti, get_cliente, create_cliente, update_cliente,
    list_progetti, get_progetto, create_progetto, update_progetto,
    list_commesse, get_commessa, create_commessa, update_commessa,
    create_timesheet, list_timesheet, approva_timesheet,
    get_dashboard_kpi, get_marginalita_clienti,
)

router = APIRouter()


# ═══════════════════════════════════════════════════════
# AUTH
# ═══════════════════════════════════════════════════════
@router.post("/auth/login", response_model=TokenResponse, tags=["Auth"])
async def login(data: LoginRequest, db: AsyncSession = Depends(get_db)):
    user = await get_user_by_email(db, data.email)
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenziali non valide")
    if not user.attivo:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account disattivato")
    token = create_access_token({"sub": str(user.id), "ruolo": user.ruolo})
    return TokenResponse(access_token=token, user=UserOut.model_validate(user))

@router.get("/auth/me", response_model=UserOut, tags=["Auth"])
async def me(current_user: User = Depends(get_current_user)):
    return current_user


# ═══════════════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════════════
@router.get("/users", response_model=List[UserOut], tags=["Users"])
async def get_users(
    attivo: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await list_users(db, attivo)

@router.post("/users", response_model=UserOut, status_code=201, tags=["Users"])
async def add_user(
    data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN))
):
    existing = await get_user_by_email(db, data.email)
    if existing:
        raise HTTPException(status_code=409, detail="Email già registrata")
    return await create_user(db, data)

@router.patch("/users/{user_id}", response_model=UserOut, tags=["Users"])
async def patch_user(
    user_id: uuid.UUID,
    data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN))
):
    user = await update_user(db, user_id, data, current_user.id)
    if not user:
        raise HTTPException(status_code=404, detail="Utente non trovato")
    return user


# ═══════════════════════════════════════════════════════
# CLIENTI
# ═══════════════════════════════════════════════════════
@router.get("/clienti", response_model=List[ClienteOut], tags=["Clienti"])
async def get_clienti(
    attivo: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await list_clienti(db, attivo)

@router.get("/clienti/{cliente_id}", response_model=ClienteOut, tags=["Clienti"])
async def get_single_cliente(
    cliente_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    c = await get_cliente(db, cliente_id)
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    return c

@router.post("/clienti", response_model=ClienteOut, status_code=201, tags=["Clienti"])
async def add_cliente(
    data: ClienteCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await create_cliente(db, data)

@router.patch("/clienti/{cliente_id}", response_model=ClienteOut, tags=["Clienti"])
async def patch_cliente(
    cliente_id: uuid.UUID,
    data: ClienteUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    c = await update_cliente(db, cliente_id, data, current_user.id)
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    return c


# ═══════════════════════════════════════════════════════
# PROGETTI
# ═══════════════════════════════════════════════════════
@router.get("/progetti", response_model=List[ProgettoWithCliente], tags=["Progetti"])
async def get_progetti(
    cliente_id: Optional[uuid.UUID] = Query(None),
    stato: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await list_progetti(db, cliente_id, stato)

@router.get("/progetti/{progetto_id}", response_model=ProgettoWithCliente, tags=["Progetti"])
async def get_single_progetto(
    progetto_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    p = await get_progetto(db, progetto_id)
    if not p:
        raise HTTPException(status_code=404, detail="Progetto non trovato")
    return p

@router.post("/progetti", response_model=ProgettoOut, status_code=201, tags=["Progetti"])
async def add_progetto(
    data: ProgettoCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await create_progetto(db, data)

@router.patch("/progetti/{progetto_id}", response_model=ProgettoOut, tags=["Progetti"])
async def patch_progetto(
    progetto_id: uuid.UUID,
    data: ProgettoUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    p = await update_progetto(db, progetto_id, data, current_user.id)
    if not p:
        raise HTTPException(status_code=404, detail="Progetto non trovato")
    return p


# ═══════════════════════════════════════════════════════
# COMMESSE
# ═══════════════════════════════════════════════════════
def _enrich_commessa(c) -> dict:
    """Aggiunge i campi calcolati alla commessa prima della serializzazione."""
    d = CommessaOut.model_validate(c).model_dump()
    d["valore_fatturabile"] = c.valore_fatturabile_calc
    d["margine_euro"] = c.margine_euro
    d["margine_percentuale"] = c.margine_percentuale
    return d

@router.get("/commesse", response_model=List[CommessaOut], tags=["Commesse"])
async def get_commesse(
    mese: Optional[date] = Query(None, description="Formato YYYY-MM-01"),
    stato: Optional[CommessaStatus] = Query(None),
    progetto_id: Optional[uuid.UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    commesse = await list_commesse(db, mese, stato, progetto_id)
    return [_enrich_commessa(c) for c in commesse]

@router.get("/commesse/{commessa_id}", response_model=CommessaOut, tags=["Commesse"])
async def get_single_commessa(
    commessa_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    c = await get_commessa(db, commessa_id)
    if not c:
        raise HTTPException(status_code=404, detail="Commessa non trovata")
    return _enrich_commessa(c)

@router.post("/commesse", response_model=CommessaOut, status_code=201, tags=["Commesse"])
async def add_commessa(
    data: CommessaCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    c = await create_commessa(db, data)
    return _enrich_commessa(c)

@router.patch("/commesse/{commessa_id}", response_model=CommessaOut, tags=["Commesse"])
async def patch_commessa(
    commessa_id: uuid.UUID,
    data: CommessaUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    c = await update_commessa(db, commessa_id, data, current_user)
    if not c:
        raise HTTPException(status_code=404, detail="Commessa non trovata")
    return _enrich_commessa(c)


# ═══════════════════════════════════════════════════════
# TIMESHEET
# ═══════════════════════════════════════════════════════
@router.get("/timesheet", response_model=List[TimesheetOut], tags=["Timesheet"])
async def get_timesheet(
    mese: Optional[date] = Query(None),
    stato: Optional[TimesheetStatus] = Query(None),
    commessa_id: Optional[uuid.UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # DIPENDENTE e FREELANCER vedono solo le proprie ore
    user_filter = None
    if current_user.ruolo in (UserRole.DIPENDENTE, UserRole.FREELANCER):
        user_filter = current_user.id
    return await list_timesheet(db, user_filter, mese, stato, commessa_id)

@router.post("/timesheet", response_model=TimesheetOut, status_code=201, tags=["Timesheet"])
async def add_timesheet(
    data: TimesheetCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return await create_timesheet(db, data, current_user.id)

@router.post("/timesheet/approva", response_model=List[TimesheetOut], tags=["Timesheet"])
async def bulk_approva(
    data: TimesheetApprova,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await approva_timesheet(db, data, current_user)


# ═══════════════════════════════════════════════════════
# REPORT / DASHBOARD
# ═══════════════════════════════════════════════════════
@router.get("/dashboard/kpi", tags=["Report"])
async def dashboard_kpi(
    mese: date = Query(..., description="Formato YYYY-MM-01"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN, UserRole.PM))
):
    return await get_dashboard_kpi(db, mese)

@router.get("/report/marginalita", tags=["Report"])
async def report_marginalita(
    mese: Optional[date] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_roles(UserRole.ADMIN))
):
    return await get_marginalita_clienti(db, mese)
