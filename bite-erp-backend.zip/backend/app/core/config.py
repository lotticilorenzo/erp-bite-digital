from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    APP_NAME: str = "Bite ERP"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://bite:bite_secret@db:5432/bite_erp"

    # JWT
    SECRET_KEY: str = "CAMBIA_QUESTA_CHIAVE_IN_PRODUZIONE"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480  # 8 ore

    # Fatture in Cloud
    FIC_API_KEY: str = ""
    FIC_BASE_URL: str = "https://api.fattureincloud.it/v2"

    # ClickUp
    CLICKUP_API_TOKEN: str = ""
    CLICKUP_BASE_URL: str = "https://api.clickup.com/api/v2"
    CLICKUP_TEAM_ID: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
