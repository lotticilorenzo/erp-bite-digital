"""
services.py — Tutta la business logic separata dagli endpoint.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import selectinload

from app.models.models import (
    User, Cliente, Progetto, Commessa, Timesheet, Task,
    Costo, AuditLog, UserRole, CommessaStatus, TimesheetStatus
)
from app.schemas.schemas import (
    UserCreate, UserUpdate, ClienteCreate, ClienteUpdate,
    ProgettoCreate, ProgettoUpdate, CommessaCreate, CommessaUpdate,
    TimesheetCreate, CostoCreate, CoefficienteCreate, TimesheetApprova
)
from app.core.security import hash_password


# ── AUDIT ─────────────────────────────────────────────────
async def write_audit(
    db: AsyncSession, user_id: uuid.UUID,
    tabella: str, record_id: uuid.UUID,
    azione: str, prima: dict = None, dopo: dict = None
):
    log = AuditLog(
        user_id=user_id, tabella=tabella, record_id=record_id,
        azione=azione, dati_prima=prima, dati_dopo=dopo
    )
    db.add(log)


# ── USER SERVICE ──────────────────────────────────────────
async def get_user_by_id(db: AsyncSession, user_id: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.id == uuid.UUID(user_id)))
    return result.scalar_one_or_none()

async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()

async def create_user(db: AsyncSession, data: UserCreate) -> User:
    user = User(
        nome=data.nome, cognome=data.cognome, email=data.email,
        password_hash=hash_password(data.password),
        ruolo=data.ruolo, costo_orario=data.costo_orario,
        data_inizio=data.data_inizio
    )
    db.add(user)
    await db.flush()
    return user

async def list_users(db: AsyncSession, attivo: Optional[bool] = None) -> List[User]:
    q = select(User)
    if attivo is not None:
        q = q.where(User.attivo == attivo)
    result = await db.execute(q.order_by(User.cognome))
    return result.scalars().all()

async def update_user(db: AsyncSession, user_id: uuid.UUID, data: UserUpdate, by_user_id: uuid.UUID) -> Optional[User]:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        return None
    prima = {"ruolo": user.ruolo, "costo_orario": str(user.costo_orario), "attivo": user.attivo}
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(user, field, val)
    await write_audit(db, by_user_id, "users", user_id, "UPDATE", prima)
    await db.flush()
    return user


# ── CLIENTE SERVICE ───────────────────────────────────────
async def list_clienti(db: AsyncSession, attivo: Optional[bool] = None) -> List[Cliente]:
    q = select(Cliente)
    if attivo is not None:
        q = q.where(Cliente.attivo == attivo)
    result = await db.execute(q.order_by(Cliente.ragione_sociale))
    return result.scalars().all()

async def get_cliente(db: AsyncSession, cliente_id: uuid.UUID) -> Optional[Cliente]:
    result = await db.execute(select(Cliente).where(Cliente.id == cliente_id))
    return result.scalar_one_or_none()

async def create_cliente(db: AsyncSession, data: ClienteCreate) -> Cliente:
    c = Cliente(**data.model_dump())
    db.add(c)
    await db.flush()
    return c

async def update_cliente(db: AsyncSession, cliente_id: uuid.UUID, data: ClienteUpdate, by_user_id: uuid.UUID) -> Optional[Cliente]:
    c = await get_cliente(db, cliente_id)
    if not c:
        return None
    prima = {"ragione_sociale": c.ragione_sociale, "attivo": c.attivo}
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(c, field, val)
    await write_audit(db, by_user_id, "clienti", cliente_id, "UPDATE", prima)
    await db.flush()
    return c


# ── PROGETTO SERVICE ──────────────────────────────────────
async def list_progetti(
    db: AsyncSession,
    cliente_id: Optional[uuid.UUID] = None,
    stato: Optional[str] = None
) -> List[Progetto]:
    q = select(Progetto).options(selectinload(Progetto.cliente))
    if cliente_id:
        q = q.where(Progetto.cliente_id == cliente_id)
    if stato:
        q = q.where(Progetto.stato == stato)
    result = await db.execute(q.order_by(Progetto.nome))
    return result.scalars().all()

async def get_progetto(db: AsyncSession, progetto_id: uuid.UUID) -> Optional[Progetto]:
    result = await db.execute(
        select(Progetto).options(selectinload(Progetto.cliente))
        .where(Progetto.id == progetto_id)
    )
    return result.scalar_one_or_none()

async def create_progetto(db: AsyncSession, data: ProgettoCreate) -> Progetto:
    p = Progetto(**data.model_dump())
    db.add(p)
    await db.flush()
    return p

async def update_progetto(db: AsyncSession, progetto_id: uuid.UUID, data: ProgettoUpdate, by_user_id: uuid.UUID) -> Optional[Progetto]:
    p = await get_progetto(db, progetto_id)
    if not p:
        return None
    prima = {"stato": p.stato, "importo_fisso": str(p.importo_fisso)}
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(p, field, val)
    await write_audit(db, by_user_id, "progetti", progetto_id, "UPDATE", prima)
    await db.flush()
    return p


# ── COMMESSA SERVICE ──────────────────────────────────────
async def list_commesse(
    db: AsyncSession,
    mese: Optional[date] = None,
    stato: Optional[CommessaStatus] = None,
    progetto_id: Optional[uuid.UUID] = None,
) -> List[Commessa]:
    q = select(Commessa).options(selectinload(Commessa.progetto).selectinload(Progetto.cliente))
    if mese:
        q = q.where(Commessa.mese_competenza == mese.replace(day=1))
    if stato:
        q = q.where(Commessa.stato == stato)
    if progetto_id:
        q = q.where(Commessa.progetto_id == progetto_id)
    result = await db.execute(q.order_by(Commessa.mese_competenza.desc()))
    return result.scalars().all()

async def get_commessa(db: AsyncSession, commessa_id: uuid.UUID) -> Optional[Commessa]:
    result = await db.execute(
        select(Commessa)
        .options(selectinload(Commessa.progetto).selectinload(Progetto.cliente))
        .where(Commessa.id == commessa_id)
    )
    return result.scalar_one_or_none()

async def create_commessa(db: AsyncSession, data: CommessaCreate) -> Commessa:
    # Eredita i valori economici dal progetto se non specificati
    progetto = await get_progetto(db, data.progetto_id)
    c = Commessa(
        progetto_id=data.progetto_id,
        mese_competenza=data.mese_competenza.replace(day=1),
        importo_fisso=data.importo_fisso,
        importo_variabile=data.importo_variabile,
        delivery_attesa=data.delivery_attesa,
        note=data.note
    )
    db.add(c)
    await db.flush()
    return c

async def update_commessa(
    db: AsyncSession,
    commessa_id: uuid.UUID,
    data: CommessaUpdate,
    current_user: User
) -> Optional[Commessa]:
    c = await get_commessa(db, commessa_id)
    if not c:
        return None

    # Blocco modifica per commesse chiuse: solo ADMIN può
    if c.is_locked and current_user.ruolo not in (UserRole.ADMIN,):
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Commessa bloccata: solo ADMIN può modificarla")

    prima = {
        "stato": c.stato, "delivery_consuntiva": c.delivery_consuntiva,
        "importo_fisso": str(c.importo_fisso)
    }

    for field, val in data.model_dump(exclude_none=True).items():
        setattr(c, field, val)

    # Se la commessa passa a CHIUSA, registra la data
    if data.stato == CommessaStatus.CHIUSA and not c.data_chiusura:
        c.data_chiusura = date.today()

    await write_audit(db, current_user.id, "commesse", commessa_id, "UPDATE", prima)
    await db.flush()
    return c


# ── TIMESHEET SERVICE ─────────────────────────────────────
async def create_timesheet(
    db: AsyncSession,
    data: TimesheetCreate,
    user_id: uuid.UUID
) -> Timesheet:
    t = Timesheet(
        user_id=user_id,
        task_id=data.task_id,
        commessa_id=data.commessa_id,
        data_attivita=data.data_attivita,
        mese_competenza=data.mese_competenza.replace(day=1),
        servizio=data.servizio,
        durata_minuti=data.durata_minuti,
        note=data.note
    )
    db.add(t)
    await db.flush()
    return t

async def list_timesheet(
    db: AsyncSession,
    user_id: Optional[uuid.UUID] = None,
    mese: Optional[date] = None,
    stato: Optional[TimesheetStatus] = None,
    commessa_id: Optional[uuid.UUID] = None,
) -> List[Timesheet]:
    q = select(Timesheet).options(selectinload(Timesheet.user))
    if user_id:
        q = q.where(Timesheet.user_id == user_id)
    if mese:
        q = q.where(Timesheet.mese_competenza == mese.replace(day=1))
    if stato:
        q = q.where(Timesheet.stato == stato)
    if commessa_id:
        q = q.where(Timesheet.commessa_id == commessa_id)
    result = await db.execute(q.order_by(Timesheet.data_attivita.desc()))
    return result.scalars().all()

async def approva_timesheet(
    db: AsyncSession,
    data: TimesheetApprova,
    approver: User
) -> List[Timesheet]:
    """Approva o rifiuta un batch di timesheet. Solo PM e ADMIN."""
    if approver.ruolo not in (UserRole.ADMIN, UserRole.PM):
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Solo PM e ADMIN possono approvare le ore")

    nuovo_stato = TimesheetStatus.APPROVATO if data.azione == "APPROVA" else TimesheetStatus.RIFIUTATO
    result = await db.execute(
        select(Timesheet).where(
            and_(Timesheet.id.in_(data.ids), Timesheet.stato == TimesheetStatus.PENDING)
        )
    )
    entries = result.scalars().all()
    for t in entries:
        t.stato = nuovo_stato
        t.approvato_da = approver.id
        t.approvato_at = datetime.utcnow()

    await db.flush()
    return entries


# ── REPORT SERVICE ────────────────────────────────────────
async def get_dashboard_kpi(db: AsyncSession, mese: date) -> dict:
    mese_norm = mese.replace(day=1)

    # Fatturato competenza (commesse chiuse/fatturate/incassate del mese)
    r = await db.execute(
        select(func.sum(Commessa.valore_fatturabile_calc))
        .where(and_(
            Commessa.mese_competenza == mese_norm,
            Commessa.stato.in_([CommessaStatus.CHIUSA, CommessaStatus.FATTURATA, CommessaStatus.INCASSATA])
        ))
    )
    # Usiamo la colonna calcolata del DB direttamente
    from sqlalchemy import text
    r2 = await db.execute(text("""
        SELECT
            COALESCE(SUM(valore_fatturabile), 0) AS fatturato,
            COUNT(*) FILTER (WHERE stato = 'PRONTA_CHIUSURA') AS pronte_chiusura,
            COALESCE(SUM(valore_fatturabile) FILTER (WHERE stato IN ('PRONTA_CHIUSURA','APERTA')), 0) AS da_emettere
        FROM commesse
        WHERE mese_competenza = :mese
    """), {"mese": mese_norm})
    row = r2.fetchone()

    pending_ts = await db.execute(
        select(func.count(Timesheet.id)).where(Timesheet.stato == TimesheetStatus.PENDING)
    )

    return {
        "mese_competenza": mese_norm,
        "fatturato_competenza": row.fatturato if row else Decimal("0"),
        "fatturato_da_emettere": row.da_emettere if row else Decimal("0"),
        "commesse_pronte_chiusura": row.pronte_chiusura if row else 0,
        "timesheet_pending": pending_ts.scalar() or 0,
    }

async def get_marginalita_clienti(db: AsyncSession, mese: Optional[date] = None) -> List[dict]:
    from sqlalchemy import text
    where = "WHERE c.mese_competenza = :mese" if mese else ""
    params = {"mese": mese.replace(day=1)} if mese else {}
    r = await db.execute(text(f"""
        SELECT
            cl.id AS cliente_id,
            cl.ragione_sociale,
            COALESCE(SUM(c.valore_fatturabile), 0)  AS fatturato,
            COALESCE(SUM(c.costo_manodopera), 0)    AS costo_manodopera,
            COALESCE(SUM(c.costi_diretti), 0)        AS costi_diretti,
            COALESCE(SUM(c.valore_fatturabile - c.costo_manodopera - c.costi_diretti), 0) AS margine_euro,
            COUNT(c.id) AS num_commesse
        FROM clienti cl
        JOIN progetti p ON p.cliente_id = cl.id
        JOIN commesse c ON c.progetto_id = p.id
        {where}
        GROUP BY cl.id, cl.ragione_sociale
        ORDER BY margine_euro DESC
    """), params)
    rows = r.fetchall()
    result = []
    for row in rows:
        pct = None
        if row.fatturato and row.fatturato > 0:
            pct = round(float(row.margine_euro / row.fatturato * 100), 1)
        result.append({
            "cliente_id": row.cliente_id,
            "ragione_sociale": row.ragione_sociale,
            "fatturato": row.fatturato,
            "costo_manodopera": row.costo_manodopera,
            "costi_diretti": row.costi_diretti,
            "margine_euro": row.margine_euro,
            "margine_percentuale": pct,
            "num_commesse": row.num_commesse,
        })
    return result
